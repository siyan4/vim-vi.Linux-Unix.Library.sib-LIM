### I'm using NeoVim now
### [Here](https://github.com/theniceboy/nvim) is my config

