# 视频中的配置在[vimrc](https://github.com/theniceboy/vimrc-example/blob/master/vimrc)文件中

